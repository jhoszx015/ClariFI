'use client'

import { useRouter } from 'next/navigation'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { useAuthStore } from '@/lib/store/auth-store'
import { Building2, PenLine } from 'lucide-react'

export function OnboardingGate() {
  const user = useAuthStore((s) => s.user)
  const completeOnboarding = useAuthStore((s) => s.completeOnboarding)
  const router = useRouter()

  const open = Boolean(user && user.onboardingCompleted === false)

  return (
    <Dialog open={open}>
      <DialogContent
        showCloseButton={false}
        className="sm:max-w-md"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="text-xl">Conecte sua conta bancária para começar</DialogTitle>
          <DialogDescription>
            Você pode conectar agora ou cadastrar manualmente. Em ambos os casos o app fica liberado; a
            conexão bancária pode ser feita depois.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-0.5 pt-2">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Escolha</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button
            type="button"
            className="flex-1 gap-2"
            onClick={() => {
              completeOnboarding('bank')
              router.push('/dashboard/conexao-bancaria')
            }}
          >
            <Building2 className="h-4 w-4" />
            Conectar banco
          </Button>
          <Button
            type="button"
            variant="secondary"
            className="flex-1 gap-2"
            onClick={() => {
              completeOnboarding('manual')
            }}
          >
            <PenLine className="h-4 w-4" />
            Adicionar conta manualmente
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
