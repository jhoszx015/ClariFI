'use client'

import { useEffect } from 'react'
import { useAiAssistant } from '@/components/clarifi/ai-assistant-context'
import { DashboardPanelBack } from '@/components/clarifi/dashboard-panel-back'

export default function AssistenteIaPage() {
  const { setOpen } = useAiAssistant()

  useEffect(() => {
    setOpen(true)
  }, [setOpen])

  return (
    <div className="mx-auto max-w-lg space-y-6 py-10 text-center">
      <DashboardPanelBack />
      <p className="text-sm text-muted-foreground">
        O assistente de IA abriu no canto inferior direito. Você pode navegar pelo aplicativo enquanto conversa. Se
        fechar o painel, clique em &quot;Assistente de IA&quot; no menu para abrir novamente.
      </p>
    </div>
  )
}
