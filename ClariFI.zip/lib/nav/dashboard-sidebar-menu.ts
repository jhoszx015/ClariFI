import type { LucideIcon } from 'lucide-react'
import {
  LayoutDashboard,
  Receipt,
  Sparkles,
  Building2,
  Landmark,
  Bot,
  Target,
  Brain,
  Users,
  Shield,
  TrendingUp,
  PieChart,
  CreditCard,
} from 'lucide-react'

export type SidebarNavBehavior = 'link' | 'open-ai-assistant'

export type SidebarNavItemDef = {
  title: string
  href: string
  icon: LucideIcon
  behavior?: SidebarNavBehavior
}

export type SidebarNavGroupDef = {
  id: string
  title: string
  items: SidebarNavItemDef[]
}

/** Fonte única para o menu lateral e o catálogo de atalhos do painel. */
export const DASHBOARD_SIDEBAR_MENU: SidebarNavGroupDef[] = [
  {
    id: 'overview',
    title: 'Visão geral',
    items: [
      { title: 'Painel', href: '/dashboard', icon: LayoutDashboard },
      { title: 'Transações', href: '/dashboard/transacoes', icon: Receipt },
      { title: 'Orçamento', href: '/dashboard/orcamento', icon: PieChart },
      { title: 'Cartão de crédito', href: '/dashboard/cartao', icon: CreditCard },
      { title: 'Contas', href: '/dashboard/contas', icon: Landmark },
    ],
  },
  {
    id: 'planning',
    title: 'Planejamento',
    items: [
      { title: 'Investimentos', href: '/dashboard/investimentos', icon: TrendingUp },
      { title: 'Metas', href: '/dashboard/metas', icon: Target },
      { title: 'Diagnóstico', href: '/dashboard/diagnostico', icon: Brain },
    ],
  },
  {
    id: 'people-habits',
    title: 'Pessoas e Hábitos',
    items: [
      { title: 'Finanças em conjunto', href: '/dashboard/compartilhado', icon: Users },
      { title: 'Coach financeiro', href: '/dashboard/coach', icon: Sparkles },
      { title: 'Assistente de IA', href: '/dashboard/assistente-ia', icon: Bot, behavior: 'open-ai-assistant' },
      { title: 'Controle de consumo', href: '/dashboard/controle', icon: Shield },
    ],
  },
  {
    id: 'integrations',
    title: 'Integrações',
    items: [{ title: 'Conexão bancária', href: '/dashboard/conexao-bancaria', icon: Building2 }],
  },
]
