const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function isValidEmail(email: string) {
  return EMAIL_REGEX.test(email.trim())
}

export async function requestPasswordRecovery(email: string): Promise<void> {
  const normalizedEmail = email.trim().toLowerCase()

  if (!isValidEmail(normalizedEmail)) {
    throw new Error('Informe um email válido.')
  }

  const endpoint = process.env.NEXT_PUBLIC_PASSWORD_RECOVERY_ENDPOINT

  // If configured, try real API integration first.
  if (endpoint) {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: normalizedEmail }),
    })

    if (!response.ok) {
      throw new Error('Não foi possível enviar o email de recuperação agora.')
    }

    return
  }

  const simulatedDelayMs = process.env.NODE_ENV === 'production' ? 0 : 120
  if (simulatedDelayMs > 0) {
    await new Promise((resolve) => setTimeout(resolve, simulatedDelayMs))
  }
}
