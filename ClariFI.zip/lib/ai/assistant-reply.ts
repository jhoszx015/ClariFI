/**
 * Respostas locais do assistente (demo). Cada envio gera texto derivado do input,
 * sem reuso de uma única string fixa.
 */

function hashInput(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0
  }
  return Math.abs(h)
}

const OPENERS = [
  'Sobre o que você perguntou:',
  'Considerando sua pergunta:',
  'Em linha com o que você escreveu:',
  'Olhando para o seu texto:',
]

const CLOSERS = [
  'Se quiser, detalhe valores ou prazo que ajusto a sugestão.',
  'Quanto mais contexto (valor, data, categoria), mais preciso fica o raciocínio.',
  'Registre no app para eu cruzar com seu histórico real nas próximas versões.',
]

export function buildAssistantReply(userText: string): string {
  const raw = userText.trim()
  if (!raw) {
    return 'Escreva uma pergunta para eu poder ajudar.'
  }

  const q = raw.toLowerCase()
  const h = hashInput(raw)
  const opener = OPENERS[h % OPENERS.length]
  const closer = CLOSERS[(h >> 3) % CLOSERS.length]
  const snippet =
    raw.length > 120 ? `${raw.slice(0, 117).trim()}…` : raw

  const tail = (paragraph: string) => `${opener} ${paragraph} ${closer}`

  if (q.includes('vale a pena') || q.includes('comprar') || q.includes('parcelad')) {
    return tail(
      `Para “${snippet}”, avalie: cabe no orçamento do mês, afeta metas e se vira dívida recorrente. Comparar custo total à vista vs parcelado e registrar a compra em Transações mantém o painel coerente.`,
    )
  }
  if (q.includes('economizar') || q.includes('economia') || q.includes('cortar gasto')) {
    return tail(
      `Para “${snippet}”, um plano simples: escolha uma categoria para reduzir ~10%, revise assinaturas duplicadas e automatize um valor pequeno para reserva. O Coach usa seu histórico para sugerir onde cortar com menos dor.`,
    )
  }
  if (q.includes('invest') || q.includes('cdb') || q.includes('tesouro') || q.includes('fii')) {
    return tail(
      `Sobre “${snippet}”: separar reserva líquida antes de arriscar patrimônio costuma evitar sair no prejuízo. Na aba Investimentos você acompanha alocação simulada; ajuste o horizonte conforme seu perfil.`,
    )
  }
  if (q.includes('impuls') || q.includes('noite') || (q.includes('compra') && q.includes('sem querer'))) {
    return tail(
      `Em “${snippet}”, compras fora do horário e em categorias discricionárias aumentam arrependimento. Trava de 48h e registrar o desejo antes de pagar ajudam a gamificação a reconhecer vitórias.`,
    )
  }
  if (q.includes('cartão') || q.includes('fatura') || q.includes('limite')) {
    return tail(
      `Para “${snippet}”: acompanhe fechamento, limite disponível e evite rotacionar saldo — juros compostos comem a margem. Use a aba Cartão de crédito para ver fatura, limite e alertas.`,
    )
  }
  if (q.includes('orçamento') || q.includes('orcamento') || q.includes('meta')) {
    return tail(
      `Sobre “${snippet}”: defina valores por categoria (fixo vs variável), compare gasto real no mês e ajuste o que sobra para metas. A tela Orçamento resume orçado, gasto e saldo por grupo.`,
    )
  }
  if (q.includes('quanto') && (q.includes('gast') || q.includes('paguei'))) {
    return tail(
      `Para “${snippet}”: no app, o total por categoria vem das transações do período. Filtre por mês em Transações e cruze com o gráfico do painel para ver a participação de cada rubrica.`,
    )
  }

  const generic = [
    `Respondendo a “${snippet}”: organize receitas e despesas no mês, veja onde está concentrando gastos e escolha um único ajuste testável por semana.`,
    `Para “${snippet}”: comece pelo essencial (moradia, alimentação, transporte), depois ataque uma categoria discricionária com meta numérica.`,
    `Sobre “${snippet}”: use metas e alertas para não depender só de memória — o ClariFI foi pensado para decisões repetíveis, não só um snapshot.`,
  ]
  return `${opener} ${generic[h % generic.length]} ${closer}`
}
