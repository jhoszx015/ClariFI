import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, BehavioralProfile, ProfileType } from '@/types'
import { bindFinanceStoreToUser } from '@/lib/store/finance-auth-sync'

const LEGACY_PROFILE_MAP: Record<string, ProfileType> = {
  planejador: 'poupador',
  desorganizado: 'desatento',
  conservador: 'poupador',
}

function migrateUserProfile(user: User | null): User | null {
  if (!user?.behavioralProfile) return user
  const t = user.behavioralProfile.type as string
  const mapped = LEGACY_PROFILE_MAP[t]
  if (!mapped) return user
  return {
    ...user,
    behavioralProfile: { ...user.behavioralProfile, type: mapped },
  }
}

type StoredUserRow = {
  id: string
  name: string
  email: string
  password: string
  createdAt: Date
  /** Data URL gerada pelo cliente nesta demo (persistida com a conta local). */
  avatar?: string
  subscriptionStatus?: 'free' | 'premium'
  onboardingCompleted?: boolean
  onboardingMethod?: 'bank' | 'manual'
}

interface AuthState {
  user: User | null
  users: StoredUserRow[]
  isAuthenticated: boolean
  isLoading: boolean
  hasHydrated: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void
  updateProfile: (profile: BehavioralProfile) => void
  setHydrated: (value: boolean) => void
  /** Simula assinatura ativa (integração real substitui por checkout). */
  setSubscriptionStatus: (status: 'free' | 'premium') => void
  /** Primeiro acesso: após escolher conectar banco ou conta manual. */
  completeOnboarding: (method: 'bank' | 'manual') => void
  /** Foto de perfil local (data URL nesta demo). `null` remove. */
  setUserAvatar: (dataUrl: string | null) => void
}

const seedUsers: StoredUserRow[] = [
  {
    id: '1',
    name: 'Maria Silva',
    email: 'maria@email.com',
    password: '123456',
    createdAt: new Date('2024-01-15'),
    subscriptionStatus: 'free',
    onboardingCompleted: true,
    onboardingMethod: 'manual',
  },
]
const SIMULATED_AUTH_DELAY_MS = process.env.NODE_ENV === 'production' ? 0 : 120

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      users: seedUsers,
      isAuthenticated: false,
      isLoading: false,
      hasHydrated: false,
      setHydrated: (value) => set({ hasHydrated: value }),

      login: async (email: string, password: string) => {
        set({ isLoading: true })

        if (SIMULATED_AUTH_DELAY_MS > 0) {
          await new Promise((resolve) => setTimeout(resolve, SIMULATED_AUTH_DELAY_MS))
        }

        const normalizedEmail = email.trim().toLowerCase()
        const user = get().users.find(
          (u) => u.email.toLowerCase() === normalizedEmail && u.password === password,
        )

        if (user) {
          const userWithoutPassword = { ...user }
          delete (userWithoutPassword as { password?: string }).password
          const base = userWithoutPassword as User
          const sessionUser: User = {
            ...base,
            subscriptionStatus: base.subscriptionStatus ?? user.subscriptionStatus ?? 'free',
            onboardingCompleted: user.onboardingCompleted ?? true,
            onboardingMethod: user.onboardingMethod,
            avatar: base.avatar ?? user.avatar,
          }
          set({
            user: sessionUser,
            isAuthenticated: true,
            isLoading: false,
          })
          await bindFinanceStoreToUser(sessionUser.id)
          return true
        }

        set({ isLoading: false })
        return false
      },

      register: async (name: string, email: string, password: string) => {
        set({ isLoading: true })

        if (SIMULATED_AUTH_DELAY_MS > 0) {
          await new Promise((resolve) => setTimeout(resolve, SIMULATED_AUTH_DELAY_MS))
        }

        // Check if email already exists
        const normalizedEmail = email.trim().toLowerCase()
        const existingUser = get().users.find((u) => u.email.toLowerCase() === normalizedEmail)
        if (existingUser) {
          set({ isLoading: false })
          return false
        }

        const newUser: User = {
          id: crypto.randomUUID(),
          name,
          email: normalizedEmail,
          subscriptionStatus: 'free',
          createdAt: new Date(),
          onboardingCompleted: false,
        }

        set({
          user: newUser,
          users: [...get().users, { ...newUser, password, onboardingCompleted: false }],
          isAuthenticated: true,
          isLoading: false,
        })

        await bindFinanceStoreToUser(newUser.id)
        return true
      },

      logout: () => {
        void bindFinanceStoreToUser(null)
        set({
          user: null,
          isAuthenticated: false,
        })
      },

      updateProfile: (profile: BehavioralProfile) => {
        const currentUser = get().user
        if (currentUser) {
          set({
            user: {
              ...currentUser,
              behavioralProfile: profile,
            },
          })
        }
      },

      setSubscriptionStatus: (status) => {
        const currentUser = get().user
        if (!currentUser) return
        set({
          user: { ...currentUser, subscriptionStatus: status },
          users: get().users.map((u) =>
            u.id === currentUser.id ? { ...u, subscriptionStatus: status } : u,
          ),
        })
      },

      completeOnboarding: (method) => {
        const currentUser = get().user
        if (!currentUser) return
        const updated: User = {
          ...currentUser,
          onboardingCompleted: true,
          onboardingMethod: method,
        }
        set({
          user: updated,
          users: get().users.map((u) =>
            u.id === currentUser.id ? { ...u, onboardingCompleted: true, onboardingMethod: method } : u,
          ),
        })
      },

      setUserAvatar: (dataUrl) => {
        const currentUser = get().user
        if (!currentUser) return
        const trimmed = dataUrl?.trim()
        const nextAvatar = trimmed && trimmed.length > 0 ? trimmed : undefined

        const nextSessionUser: User = nextAvatar
          ? { ...currentUser, avatar: nextAvatar }
          : (() => {
              const { avatar: _ignore, ...rest } = currentUser
              return rest as User
            })()

        const nextUsers = get().users.map((u) => {
          if (u.id !== currentUser.id) return u
          const row = { ...u }
          if (nextAvatar) row.avatar = nextAvatar
          else delete row.avatar
          return row
        })

        set({
          user: nextSessionUser,
          users: nextUsers,
        })
      },
    }),
    {
      name: 'clarifi-auth',
      version: 3,
      migrate: (persisted, fromVersion) => {
        const p = persisted as {
          user?: User | null
          users?: StoredUserRow[]
          isAuthenticated?: boolean
        }
        if (fromVersion === 0 && p?.user) {
          p.user = migrateUserProfile(p.user)
        }
        if (!p.users || p.users.length === 0) {
          p.users = seedUsers
        }
        if (fromVersion < 2) {
          p.users = p.users.map((u) => ({
            ...u,
            onboardingCompleted: u.onboardingCompleted ?? true,
          }))
          if (p.user && p.user.onboardingCompleted === undefined) {
            p.user = { ...p.user, onboardingCompleted: true }
          }
        }
        return p
      },
      onRehydrateStorage: () => (state) => {
        if (!state) return
        queueMicrotask(() => {
          state.setHydrated(true)
        })
      },
      partialize: (state) => ({
        user: state.user,
        users: state.users,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
)
